package e0210;

public class Sort {
	int o_var_val;
	String o_var;
	public Sort(int o_var_val,String o_var){
		this.o_var_val=o_var_val;
		this.o_var=o_var;
	}

}
