package e0210;

public class MyLock {
	public String lockO;
	public String unlockO;
	public MyLock(String lockO,String unlockO) {
		this.lockO=lockO;
		this.unlockO=unlockO;
	}

}
