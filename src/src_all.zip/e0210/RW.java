package e0210;

public class RW {
	String symVal;
	String order;
	public RW(String symVal,String order){
		this.symVal=symVal;
		this.order=order;
	}

}
