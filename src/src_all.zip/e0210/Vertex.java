package e0210;

import java.io.Serializable;

public class Vertex implements Serializable {
	
	private static final long serialVersionUID = 1L;
	int sBL,eBl,node;
	boolean exit;	

}
